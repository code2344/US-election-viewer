# Simple iFrame Viewer

A Pen created on CodePen.io. Original URL: [https://codepen.io/wendee/pen/AePOYE](https://codepen.io/wendee/pen/AePOYE).

Simple CSS only solution for an iFrame viewer. 

One issue with this solution is it requires a fixed height header which makes it not suitable for all situations.

Another issue is that IE7 has a double scrollbar.